package prioritybitmap

import "github.com/anacrolix/missinggo/itertools"

type Iter struct {
	it itertools.Iterator
}
